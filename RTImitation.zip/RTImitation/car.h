#ifndef CAR_H
#define CAR_H

#include <vector>
#include <QString>
#include "mainwindow.h"

//class trafficLights;
/*const bool Vertical = 1;
const bool Horisontal = 0;

const int U=1;
const int R=2;
const int D=3;
const int L=4;

const int dbr=15; //dbr - distance between roads (расстояние между путями)
const int lTl=20; //расстояние от пересечения дороги до стоп линии перекрестка*/

class Car
{
    int xCar;
    int yCar;
    int speedCar;
    int nWay; //номер дороги, на которой в данный момент находится машина
    int nTrack; //номер пути, на которой в ...
    int nLane; //номер полосы, на кот...

    bool turnedNow = 0; //Если машина повернула, то 1, ибо может вызваться обработчик на ещё 1 поворот сразу же
    bool spawned = 0; //Чтобы 2 раза не срабатывал респавн машины
    bool turnedFromThisIS = 0; //Чтобы не было 100500 поворотов на одном перекрестке

    //пока хз зачем это вводил
    std::vector <int> xWay;
    std::vector <int> yWay;
public:
    Car();
    void setXCar(int x);
    void setYCar(int y);
    void setXWay(int n, int x);
    void setYWay(int n, int y);
    void setSpeed(int speed);
    void setNWay(int n); //устанавливаем номер дороги, на которой в данный момент находится машина
    void setNTrack(int n); //устанавливаем номер пути, на кот....
    void setNLane(int n); //устанавливаем номер полосы...
    void setTurnedNow(bool n);
    void setSpawned(bool n);
    void setTurnedFromThisIS(bool n);
    int getXCar();
    int getYCar();
    int getXWay(int n);
    int getYWay(int n);
    int getSpeed();
    int getNWay(); //возвращаем номер дороги, на которой в данный момент находится машина
    int getNTrack(); //возвращаем номер пути, на кот....
    int getNLane(); //возвращаем номер полосы...
    bool getTurnedNow();
    bool getSpawned();
    bool getTurnedFromThisIS();
};






#endif // CAR_H
