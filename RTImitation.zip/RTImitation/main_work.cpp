#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <vector>

//Общие определения
interSection IS;
Way* WAY;
std::vector <trafficLights> Tl;
stl* settingTL;
sclanes* settingCL;
count_cars* cCars;

int countTl=0;
int countWay=0;
int countCars=1;

int deb=0;

bool setTlClicked = 0;
bool setApplyClicked = 0;
bool firstGoClicked = 0;

//С какой вероятностью происходит поворот a=rand() % xxxTurn;
int rightTurn=3;
int leftTurn=4;



#if 0
const bool Vertical = 1;
const bool Horisontal = 0;

const int U=1;
const int R=2;
const int D=3;
const int L=4;

const int dbr=15; //dbr - distance between roads (расстояние между путями)

//С какой вероятностью происходит поворот a=rand() % xxxTurn;
const int rightTurn=3;
const int leftTurn=3;

const int intervalTLDefault=5000;

const int intervalTL=10; //интервал для таймера светофора
const int mainInterval=4;

const int lenghtCar=16;
#endif





void MainWindow::mainTime()
{
    for (int nCar=0; nCar<countCars; ++nCar)
    {

        if (!car[nCar].getTurnedFromThisIS())
        {
        //Обработчик перекрестка
        if (!car[nCar].getTurnedNow())
            handlerIS(nCar);
        else
            car[nCar].setTurnedNow(false);
        }
        else
        {
            if (!WAY[car[nCar].getNWay()].onIS(car[nCar].getXCar(), car[nCar].getYCar()))
                car[nCar].setTurnedFromThisIS(false);
        }




        //Обработчик взаимодействия
        tempSpeed=handlerINT(nCar);
        if (tempSpeed != car[nCar].getSpeed())
            car[nCar].setSpeed(tempSpeed);

        //Обработчик светофора
        handlerTL(nCar);




        //если машина не остановлена по какой-то из причин
        if (car[nCar].getSpeed())
        {
            //Ибо из-за направления дорог, двигаться могут в разные стороны
            if (car[nCar].getNTrack()==1)
                ++a[nCar];
            else
                --a[nCar];
        }

        //qDebug() << "one" << car[nCar].getNWay();
        car[nCar].setXCar(WAY[car[nCar].getNWay()].x(car[nCar].getNTrack(),car[nCar].getNLane(),a[nCar]));
        car[nCar].setYCar(WAY[car[nCar].getNWay()].y(car[nCar].getNTrack(),car[nCar].getNLane(),a[nCar]));
        //qDebug() << "two" << car[nCar].getNWay();

        // отображение на самой сцене
        objCar[nCar].setX(car[nCar].getXCar());
        objCar[nCar].setY(car[nCar].getYCar());

        //Если только что сработал спавн, не передвигать
        if (car[nCar].getSpawned())
            car[nCar].setSpawned(false);
        else //Если машина уехала за пределы дороги, отреспавнить её на другой точке
            if (car[nCar].getXCar()==0)
                setCarWay(nCar);
    }

/*
    ui->objx->setText(QString::number(objCar[0].x()));
    ui->objy->setText(QString::number(objCar[0].y()));

    ui->objx_2->setText(QString::number(objCar[1].x()));
    ui->objy_2->setText(QString::number(objCar[1].y()));


    ui->carx->setText(QString::number(car[0].getXCar()));
    ui->cary->setText(QString::number(car[0].getYCar()));

    ui->carx_2->setText(QString::number(car[1].getXCar()));
    ui->cary_2->setText(QString::number(car[1].getYCar()));*/



}

void MainWindow::on_setTL_clicked()
{
    setTlClicked = 1;
}




