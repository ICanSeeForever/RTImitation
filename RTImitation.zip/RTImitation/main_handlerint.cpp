#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <vector>

//Общие определения

extern interSection IS;
extern Way* WAY;
extern std::vector <trafficLights> Tl;
extern stl* settingTL;

extern int countTl;
extern int countWay;
extern int countCars;

extern int deb;

extern bool setTlClicked;// = 0;
extern bool setApplyClicked;// = 0;

bool MainWindow::handlerINT(int nCar)
{
    for (int oNCar=0; oNCar<countCars; ++oNCar)
    {

        //Проверяем, что сравниваем не одну и ту же машину
        if (nCar!=oNCar)
        {
            //Если по горизонтальной дороге машина едет вправо (по напр=1трек, против=2трек)
            if (WAY[car[nCar].getNWay()].posWay()==Horisontal &&
                    ((WAY[car[nCar].getNWay()].towards() &&
                    car[nCar].getNTrack()==1) or
                     (!WAY[car[nCar].getNWay()].towards() &&
                    car[nCar].getNTrack()==2)))
            {
                //Если машина В впереди А
                if(car[oNCar].getXCar() > car[nCar].getXCar())
                {
                    //Если расстояние между ними меньше дельты
                    if(abs(car[nCar].getXCar() - car[oNCar].getXCar()) < lenghtCar+deltaCar)
                    {
                        //Если расстояние до левой части больше LT
                        if(car[oNCar].getYCar() - car[nCar].getYCar() > -LT)
                        {
                            //Если расстояние до правой части больше RT
                            if(car[oNCar].getYCar() - car[nCar].getYCar() < RT)
                            {
                                /*qDebug() << "=============";
                                qDebug() << "    nCar:" << nCar;
                                qDebug() << "   oNCar:" << oNCar;
                                qDebug() << "     ABS:" << abs(car[nCar].getYCar() - car[oNCar].getYCar());
                                qDebug() << "  lenght:" << lenghtCar;
                                qDebug() << "speed0:" << car[nCar].getSpeed();
                                qDebug() << "speed1:" << car[oNCar].getSpeed();
                                qDebug() <<"if ==";
                                if (car[oNCar].getSpeed()==0)
                                    qDebug() << "speed=0";
                                if (car[oNCar].getSpeed()!=0)
                                    qDebug() << "speed=1";
                                qDebug() <<"if !";
                                if (!car[oNCar].getSpeed())
                                    qDebug() << "speed=0";
                                if (car[oNCar].getSpeed())
                                    qDebug() << "speed=1";
                                */
                                if (!car[oNCar].getSpeed() && abs(car[nCar].getYCar() - car[oNCar].getYCar()) > lenghtCar+1)
                                {
                                    //qDebug() << "continue";
                                    continue;
                                }
                                else
                                {
                                    //qDebug() << "throw";
                                    return false;
                                }
                            }
                        }
                    }

                }
            }

            //Если по горизонтальной дороге машина едет влево (по напр=2трек, против=1трек)
            if (WAY[car[nCar].getNWay()].posWay()==Horisontal &&
                    ((WAY[car[nCar].getNWay()].towards() &&
                    car[nCar].getNTrack()==2) or
                     (!WAY[car[nCar].getNWay()].towards() &&
                    car[nCar].getNTrack()==1)))
            {
                //Если машина В впереди А
                if(car[oNCar].getXCar() < car[nCar].getXCar())
                {
                    //Если расстояние между ними меньше дельты
                    if(abs(car[nCar].getXCar() - car[oNCar].getXCar()) < lenghtCar+deltaCar)
                    {
                        //Если расстояние до левой части больше LT
                        if(car[oNCar].getYCar() - car[nCar].getYCar() < LT)
                        {
                            //Если расстояние до правой части больше RT
                            if(car[oNCar].getYCar() - car[nCar].getYCar() > -RT)
                            {
                                if (!car[oNCar].getSpeed() && abs(car[nCar].getYCar() - car[oNCar].getYCar()) > lenghtCar+1)
                                    continue;
                                else
                                    return false;
                            }
                        }
                    }
                }
            }


            //Если по вертикальной дороге машина едет вниз (по напр=1трек, против=2трек)
            if (WAY[car[nCar].getNWay()].posWay()==Vertical &&
                    ((WAY[car[nCar].getNWay()].towards() &&
                    car[nCar].getNTrack()==1) or
                     (!WAY[car[nCar].getNWay()].towards() &&
                    car[nCar].getNTrack()==2)))
            {
                //Если машина В впереди А
                if(car[oNCar].getYCar() > car[nCar].getYCar())
                {
                    //Если расстояние между ними меньше дельты
                    if(abs(car[nCar].getYCar() - car[oNCar].getYCar()) < lenghtCar+deltaCar)
                    {
                        //Если расстояние до левой части больше LT
                        if(car[oNCar].getXCar() - car[nCar].getXCar() < LT)
                        {
                            //Если расстояние до правой части больше RT
                            if(car[oNCar].getXCar() - car[nCar].getXCar() > -RT)
                            {
                                if (!car[oNCar].getSpeed() && abs(car[nCar].getXCar() - car[oNCar].getXCar()) > lenghtCar+1)
                                    continue;
                                else
                                    return false;
                            }
                        }
                    }
                }
            }

            //Если по вертикальной дороге машина едет вверх (по напр=2трек, против=1трек)
            if (WAY[car[nCar].getNWay()].posWay()==Vertical &&
                    ((WAY[car[nCar].getNWay()].towards() &&
                    car[nCar].getNTrack()==2) or
                     (!WAY[car[nCar].getNWay()].towards() &&
                    car[nCar].getNTrack()==1)))
            {
                //Если машина В впереди А
                if(car[oNCar].getYCar() < car[nCar].getYCar())
                {
                    //Если расстояние между ними меньше дельты
                    if(abs(car[nCar].getYCar() - car[oNCar].getYCar()) < lenghtCar+deltaCar)
                    {
                        //Если расстояние до левой части больше LT
                        if(car[oNCar].getXCar() - car[nCar].getXCar() > -LT)
                        {
                            //Если расстояние до правой части больше RT
                            if(car[oNCar].getXCar() - car[nCar].getXCar() < RT)
                            {
                                if (!car[oNCar].getSpeed() && abs(car[nCar].getXCar() - car[oNCar].getXCar()) > lenghtCar+1)
                                    continue;
                                else
                                    return false;
                            }
                        }
                    }
                }
            }

        }
    }

    //Если нет никаких препятствий и машина стоит, дать команду на движение
    if (!car[nCar].getSpeed())
        return true;
}
