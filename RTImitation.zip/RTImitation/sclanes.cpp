#include "sclanes.h"
#include "ui_sclanes.h"
#include "QDebug"

extern QEventLoop loop;

int sclanes::getCp()
{
    return cp;
}

int sclanes::getCm()
{//qDebug() << "SSS";
    return cm;
}

sclanes::sclanes(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::sclanes)
{
    ui->setupUi(this);

    setWindowFlags(Qt::Window
         | Qt::WindowMinimizeButtonHint
         | Qt::WindowMaximizeButtonHint
         | Qt::CustomizeWindowHint);

    cp=1;
    cm=1;
}

sclanes::~sclanes()
{
    delete ui;
}

void sclanes::show()
{
    this->setVisible(true);
    ui->countMinus->setValue(1);
    ui->countPlus->setValue(1);

    cp=1;
    cm=1;
}

void sclanes::on_pushButton_clicked()
{
    cp=ui->countPlus->value();
    cm=ui->countMinus->value();

    loop.quit();
    close();
}

void sclanes::on_pushButton_2_clicked()
{
    loop.quit();
    close();
}

void sclanes::keyPressEvent(QKeyEvent *event)
{
    if(event->key()==Qt::Key_Enter)
    {
        on_pushButton_clicked();
    }
}


