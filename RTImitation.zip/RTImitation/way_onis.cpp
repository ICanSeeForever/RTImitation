#include "way.h"

bool Way::onIS(int X, int Y)
{
    for (int i=0; i<cIS; ++i)
    {
        if (horizontalWay)
        {
            if (X>=cMin[i] && X<=cMax[i])
                return true;
            else
                return false;
        }
        else
        {
            if (Y>=cMin[i] && Y<=cMax[i])
                return true;
            else
                return false;
        }
    }
}
