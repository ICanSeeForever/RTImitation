#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <vector>


//Общие определения

extern interSection IS;
extern Way* WAY;
extern std::vector <trafficLights> Tl;
extern stl* settingTL;

extern int countTl;
extern int countWay;
//extern int countCars;

//extern int deb;

extern bool setTlClicked;// = 0;
extern bool setApplyClicked;// = 0;

void paintScene::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
{
    if (!setApplyClicked)
    {

        // Рисование линии с использованием предыдущей координаты
        addLine(previousPoint.x(),
                previousPoint.y(),
                event->scenePos().x(),
                event->scenePos().y(),
                QPen( Qt::black ,1,Qt::SolidLine,Qt::RoundCap));

        // Обновление данных о предыдущей координате

        x2=previousPoint.x();
        y2=previousPoint.y();
        /*
    WAY.setX(n, previousPoint.x());
    WAY.setY(n, previousPoint.y());
    ++n;*/
        previousPoint = event->scenePos();




    }

}
