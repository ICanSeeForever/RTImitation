#ifndef INTERSECTION_H
#define INTERSECTION_H

#include <vector>
#include <QString>
#include "mainwindow.h"

/*const bool Vertical = 1;
const bool Horisontal = 0;

const int U=1;
const int R=2;
const int D=3;
const int L=4;

const int dbr=15; //dbr - distance between roads (расстояние между путями)
const int lTl=20; //расстояние от пересечения дороги до стоп линии перекрестка*/

class interSection
{
    std::vector< std::vector<int>> xIS;
    std::vector< std::vector<int>> yIS;
    int cWay;
    QString debugg;

    //нач. и кон. перекрестка
    int xMinIS;
    int xMaxIS;
    int yMinIS;
    int yMaxIS;
public:
    void setIS(int nWay1, int nWay2, int xc, int yc);
    void setCWay(int c);

    int getXIS(int nWay1, int nWay2);
    int getYIS(int nWay1, int nWay2);

    /*//Находится ли машина с корами Х У на текущем перекрестке
    bool onIS(int X, int Y);*/


};

#endif // INTERSECTION_H
