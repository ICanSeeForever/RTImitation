#ifndef STL_H
#define STL_H

#include <QWidget>
#include <QValidator>
#include <vector>

namespace Ui {
class stl;
}

class stl : public QWidget
{
    Q_OBJECT
    std::vector <int> xInterval;
    std::vector <int> yInterval;
    int nowTL;
    int countTL;

public:
    void settTL(int n, int count);

    int getXinterval (int n);
    int getYinterval (int n);

    void setting(int count);


    explicit stl(QWidget *parent = 0);
    ~stl();

private slots:
    void on_pushSet_clicked();

    void on_cancel_clicked();

private:
    Ui::stl *ui;
};

#endif // STL_H
