#if 1
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <vector>

extern QEventLoop loop;
//Общие определения

//extern interSection IS;
extern Way* WAY;
extern std::vector <trafficLights> Tl;
extern stl* settingTL;
extern count_cars* cCars;

extern int countTl;
//extern int countWay;
extern int countCars;

extern bool firstGoClicked;

/*
//С какой вероятностью происходит поворот a=rand() % xxxTurn;
const int rightTurn=3;
const int leftTurn=3;

const int intervalTLDefault=5000;

const int intervalTL=10; //интервал для таймера светофора
const int mainInterval=4;

const int lenghtCar=16;

*/

void MainWindow::on_go_clicked()
{
    if (!GO)
    {
        GO=true;
        ui->go->setText("Stop");
        if (!firstGoClicked)
        {
            firstGoClicked=true;
            ui->setTL->setEnabled(false);
            ui->apply->setEnabled(false);

            settingTL[0].setting(countTl);

            //countCars=2;

            //Пока что костыль. Установка первого положения машины на 0,0. Иначе криво едет по дороге
            /*WAY[0].setX(0,0);
        WAY[0].setY(0,0);*/

            cCars[0].show();
            loop.exec();
            //qDebug() << "SSS";
            countCars=cCars[0].getCountCars();
            //qDebug() << "FFF";
            objCar = new QGraphicsItemGroup[countCars];
            car = new Car[countCars]; //создаём 2 машины
            a = new int[countCars];

            //ttt[0].addToGroup(scene->addRect(10,20,20,20,QPen(Qt::NoPen),QBrush(Qt::red)));

            //scene->addItem(ttt);

            //ttt->setX(500);

            //objCar.resize(2);//s = new QGraphicsItem[2];

            for (int i=0; i<countCars; ++i)
            {
                //Устанавливаем машину на начало пути
                car[i].setXCar(WAY[0].x(1,0,0));
                car[i].setYCar(WAY[0].y(1,0,0));

                //addRect значения 30 и 16 - длина и ширина машины
                //поэтому, отнимаем 15 и 8 от координат, чтобы она находилась по центру дороги
                objCar[i].addToGroup(scene->addRect(car[i].getXCar()-lenghtCar/2,car[i].getYCar()-lenghtCar/2,lenghtCar,lenghtCar,    QPen(Qt::NoPen),
                                                    i==0 ? QBrush(Qt::red) :
                                                           i==1 ? QBrush(Qt::yellow) :
                                                                  i==2 ? QBrush(Qt::green) :
                                                                         i==3 ? QBrush(Qt::blue) :
                                                                                i==4 ? QBrush(Qt::cyan) :
                                                                                       QBrush(Qt::black)




                                                                                       ));
                scene->addItem(&objCar[i]);
            }



            //objCar[0].setTransformOriginPoint(0,0);


            //qDebug() << WAY[0].x(0,0,WAY[0].getLengthWay()-1);

            //Устанавливаем интервалы на светофор (которые настраивали)
            for (int i=0; i<countTl; ++i)
            {
                if (settingTL[0].getXinterval(i) && settingTL[0].getYinterval(i))
                {
                    Tl[i].setIntervalX(settingTL[0].getXinterval(i));
                    Tl[i].setIntervalY(settingTL[0].getYinterval(i));
                }
                else
                {
                    Tl[i].setIntervalX(intervalTLDefault);
                    Tl[i].setIntervalY(intervalTLDefault);
                }
            }

            for (int i=0; i<countCars; ++i)
                setCarWay(i);

            mainTimer = new QTimer();       // Инициализация таймера
            TLtimer = new QTimer();
            connect(mainTimer, &QTimer::timeout, this, &MainWindow::mainTime);
            connect(TLtimer, &QTimer::timeout, this, &MainWindow::tlTime);

            for (int i=0; i<countCars; ++i)
                car[i].setSpeed(1);


            //Tl[0].setXAllow();

            tlTime();
        }
        TLtimer->start(intervalTL/*5000*//*Tl[0].getInterval()*/);
        mainTimer->start(mainInterval);
        //mainTimer->setInterval(5);
    }
    else
    {
        GO=false;
        ui->go->setText("Go");
        mainTimer->stop();
        TLtimer->stop();
    }
}
#endif
