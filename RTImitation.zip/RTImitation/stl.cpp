#include "stl.h"
#include "ui_stl.h"
#define intNotation new QRegExpValidator(QRegExp("[0-9]{1,9}"))


stl::stl(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::stl)
{
    ui->setupUi(this);
}

void stl::settTL(int n, int count)
{
    nowTL=n;
    countTL=count;

    xInterval.resize(countTL);
    yInterval.resize(countTL);

    ui->intX->setText(QString::number(xInterval[nowTL]));
    ui->intY->setText(QString::number(yInterval[nowTL]));
}

int stl::getXinterval(int n)
{
    return xInterval[n];
}

int stl::getYinterval(int n)
{
    return yInterval[n];
}

void stl::setting(int count)
{
    countTL=count;

    xInterval.resize(countTL);
    yInterval.resize(countTL);

}

void stl::on_pushSet_clicked()
{
    xInterval[nowTL]=ui->intX->text().toInt();
    yInterval[nowTL]=ui->intY->text().toInt();

    hide();
}

void stl::on_cancel_clicked()
{
    hide();
}


stl::~stl()
{
    delete ui;
}
