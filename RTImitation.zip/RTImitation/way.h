#ifndef WAY_H
#define WAY_H

#include <vector>
#include <QString>
#include "mainwindow.h"

/*const bool Vertical = 1;
const bool Horisontal = 0;

const int U=1;
const int R=2;
const int D=3;
const int L=4;

const int dbr=15; //dbr - distance between roads (расстояние между путями)
const int lTl=20; //расстояние от пересечения дороги до стоп линии перекрестка*/

class Way
{

    // [i][j][k]
    // i - номер направления. 0 - основная линия, 1 - по направлению, 2 - против направления
    // j - номер пути в направлении (по умолчанию тут 0, ибо одна дорога). Если 1, то 2 пути в этом направлении
    // k - координата в пространстве
    std::vector< std::vector < std::vector <int> > > X;
    std::vector< std::vector < std::vector <int> > > Y;
    // Номера перекрестков (пересечений путей) [i][j]
    // i - номер направления
    // j - номер перекрестка
    std::vector< std::vector< std::vector<int>>> xISR;
    std::vector< std::vector< std::vector<int>>> xISL;
    std::vector< std::vector< std::vector<int>>> yISR;
    std::vector< std::vector< std::vector<int>>> yISL;
    // Номер дороги указанного перекрёстка (путей)
    std::vector< std::vector<int>> nWayIS;
    //количество полос пересекаемой дороги на указанном перекрёстке
    std::vector<int> countPlusIS;
    std::vector<int> countMinusIS;
    
    //коры начала и конца перекрестка
    std::vector<int> cMin;
    std::vector<int> cMax;



    //std::vector<trafficLights> TLs; //перекрестки


    int countStripPlus; //количество полос по направлению
    int countStripMinus; //Количество полос против направления
    int sumStrip; //суммарное количество полос
    int lengthWay; //длина дороги
    int cIS; //количество перекрестков на данной дороге
    int cTL; //количество светофоров на данной дороге
    bool vertikalWay; //одно значение, либо вертикальная, либо горизонтальная
    bool horizontalWay;
    bool tw; // (towards) По направлению дорога, или против (вот зачем я ввёл эту штуку с направлениями? Т_Т)
    //bool D; //переменная отвечает за установку направления дорог
public:
    Way();
    int x(int i, int j, int k);
    int y(int i, int j, int k);
    int getLengthWay();
    int getCountStripPlus(); //возвращаем кол-во полос по направлению
    int getCountStripMinus();
    bool posWay(); // возвращаем инфу о дороге (вертикальная или горизонтальная)
    bool towards(); // возвращаем инфу о дороге (1 - по направлению. 2 - против)
    int getXISR(int nt, int n, int np); //возвращаем коры перекрестка
    int getYISR(int nt, int n, int np);
    int getXISL(int nt, int n, int np);
    int getYISL(int nt, int n, int np);
    int getCIS(); //возвращает количество перекрестков на текущей дороге
    int getNWayIS(int nTrack, int n); //возвращаем номер дороги на перекрестке n пути nTrack
    int getCountPlusIS(int cis); //возвращаем кол-во полос пересекаемой дороги на указанном перекрестке
    int getCountMinusIS(int cis);
    bool onIS(int X, int Y); //на перекрестке ли машина

    void setLength(int l);
    void setX(int n, int X);
    void setY(int n, int Y);
    void setWay(int direcrion, int x, int y, int n, int c);
    //xs, ys - коры пересечения центр. линии
    //csP, csM - кол-во полос по и против направления у пересекающей дороги
    //pos - верт. или гор. дорога (которая пересекает текущую)
    //nWay - номер дороги, с которой идёт пересечение
    //IS в названии - intersection (перекрёсток)
    void setIS(int xc, int yc, int csP, int csM, bool pos, int nWay);
    void setTowards(bool tow);
    void setCountStripPlus(int c); //устанавливаем кол-во полос по направлению
    void setCountStripMinus(int c);

    //устанавливаем координату светофора
    //void setTLIS(int xc, int yc, int nWay1, int nWay2);



};


#endif // WAY_H
