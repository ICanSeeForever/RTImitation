#ifndef COUNT_CARS_H
#define COUNT_CARS_H

#include <QWidget>

namespace Ui {
class count_cars;
}

class count_cars : public QWidget
{
    Q_OBJECT

    int cc;

public:
    explicit count_cars(QWidget *parent = 0);
    ~count_cars();

    int getCountCars();

private slots:
    void on_pok_clicked();

    void on_pcancel_clicked();

private:
    Ui::count_cars *ui;
};

#endif // COUNT_CARS_H
