#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <vector>


//Общие определения

extern interSection IS;
extern Way* WAY;
extern std::vector <trafficLights> Tl;
extern stl* settingTL;

extern int countTl;
extern int countWay;
//extern int countCars;

//extern int deb;

extern bool setTlClicked;// = 0;
extern bool setApplyClicked;// = 0;

void paintScene::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    if (!setApplyClicked)
    {
        // Если будет время, переделать. В данный момент, просто максимум 30 дорог может быть
        /*if (countWay==0)
            WAY = new Way[30];*/

        x1=event->scenePos().x();
        y1=event->scenePos().y();
        // При нажатии кнопки мыши рисуется эллипс
        addEllipse(event->scenePos().x(),
                   event->scenePos().y(),
                   1,
                   1,
                   QPen(Qt::NoPen),
                   QBrush(Qt::black) );
        // Координата точки нажатия
        previousPoint = event->scenePos();
    }
    else
    {
        if (setTlClicked)
    {
            if (event->buttons() == Qt::RightButton )
            {
                for (int i=0; i<countTl; ++i)
                {
                    if (abs(Tl[i].getX0() - event->scenePos().x()) < 20 &&
                            abs(Tl[i].getY0() - event->scenePos().y()) < 20 )
                    {
                        settingTL[0].settTL(i,countTl);
                        settingTL[0].show();
                    }
                }
            }
            else
            {
                if (event->buttons() == Qt::LeftButton )
                {
                    //msg.setText("Перекресток");//QString::number (event->scenePos().y()));
                    for (int i=0; i<countWay; ++i)
                    {
                        if (WAY[i].posWay()==Horisontal)
                        {
                            for (int j=0; j<countWay; ++j)
                            {
                                if (abs(IS.getXIS(i,j) - event->scenePos().x()) < 20 &&
                                        abs(IS.getYIS(i,j) - event->scenePos().y()) < 20 )
                                {

                                    Tl.resize(countTl+1);
                                    //IS.getXIS(1,1);
                                    Tl[countTl].setTL(i,j, IS.getXIS(i,j),IS.getYIS(i,j),
                                                (WAY[i].x(0,0,1) < WAY[i].x(0,0,2) ? R : L),
                                                (WAY[j].x(0,0,1) < WAY[j].x(0,0,2) ? D : U) );
                                    ++countTl;

                                    msg.setText("Светофор на пересечении дорог " + QString::number(i) + " и " + QString::number(j) + " успешно установлен");
                                    msg.exec();
                                }
                            }
                        }
                    }
                }
            }






    }

    }
}
