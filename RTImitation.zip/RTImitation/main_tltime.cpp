#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <vector>


//Общие определения

extern interSection IS;
extern Way* WAY;
extern std::vector <trafficLights> Tl;
extern stl* settingTL;

extern int countTl;
extern int countWay;
//extern int countCars;

//extern int deb;

extern bool setTlClicked;// = 0;
extern bool setApplyClicked;// = 0;


void MainWindow::tlTime()
{


    for (int i=0; i<countTl; ++i)
    {
        int nWay1=Tl[i].getNWay1();
        int nWay2=Tl[i].getNWay2();
        if (Tl[i].xAllowed())
        {
            if (Tl[i].beep(1,0,intervalTL))
            {
                Tl[i].setYAllow();
                //mainTimer->setInterval(mainInterval);
                scene->addLine(Tl[i].getCoordX1(1,lastLane),Tl[i].getCoordY1(1,lastLane),
                               Tl[i].getCoordX1(1,lastLane),
                               Tl[i].getCoordY1(1,lastLane)- dbr/2 -(dbr*(WAY[nWay1].getCountStripPlus()-1)),QPen(Qt::red));

                scene->addLine(Tl[i].getCoordX1(2,lastLane),Tl[i].getCoordY1(2,lastLane),
                               Tl[i].getCoordX1(2,lastLane),
                               Tl[i].getCoordY1(2,lastLane)+ dbr/2 +(dbr*(WAY[nWay1].getCountStripMinus()-1)),QPen(Qt::red));

                scene->addLine(Tl[i].getCoordX2(1,lastLane),Tl[i].getCoordY2(1,lastLane),
                               Tl[i].getCoordX2(1,lastLane)+dbr/2 +(dbr*(WAY[nWay2].getCountStripPlus()-1)),Tl[i].getCoordY2(1,lastLane), QPen(Qt::green));

                scene->addLine(Tl[i].getCoordX2(2,lastLane),Tl[i].getCoordY2(2,lastLane),
                               Tl[i].getCoordX2(2,lastLane)-dbr/2 -(dbr*(WAY[nWay2].getCountStripMinus()-1)),Tl[i].getCoordY2(2,lastLane), QPen(Qt::green));

                //(WAY[nWay1].x(0,0,1) < WAY[nWay1].x(0,0,2) ? R : L),
                //(WAY[nWay2].x(0,0,1) < WAY[nWay2].x(0,0,2) ? D : U) );
            }
        }
        else
        { //or - для первого прохода
            if (Tl[i].beep(0,1,intervalTL) or !TLtimer->isActive())
            {
                Tl[i].setXAllow();
                //mainTimer->setInterval(mainInterval);

                scene->addLine(Tl[i].getCoordX1(1,lastLane),Tl[i].getCoordY1(1,lastLane),
                               Tl[i].getCoordX1(1,lastLane),
                               Tl[i].getCoordY1(1,lastLane)- dbr/2 -(dbr*(WAY[nWay1].getCountStripPlus()-1)),QPen(Qt::green));

                scene->addLine(Tl[i].getCoordX1(2,lastLane),Tl[i].getCoordY1(2,lastLane),
                               Tl[i].getCoordX1(2,lastLane),
                               Tl[i].getCoordY1(2,lastLane)+ dbr/2 +(dbr*(WAY[nWay1].getCountStripMinus()-1)),QPen(Qt::green));

                scene->addLine(Tl[i].getCoordX2(1,lastLane),Tl[i].getCoordY2(1,lastLane),
                               Tl[i].getCoordX2(1,lastLane)+ dbr/2 +(dbr*(WAY[nWay2].getCountStripPlus()-1)),
                               Tl[i].getCoordY2(1,lastLane), QPen(Qt::red));

                scene->addLine(Tl[i].getCoordX2(2,lastLane),Tl[i].getCoordY2(2,lastLane),
                               Tl[i].getCoordX2(2,lastLane)- dbr/2 -(dbr*(WAY[nWay2].getCountStripMinus()-1)),
                               Tl[i].getCoordY2(2,lastLane), QPen(Qt::red));

            }
        }
    }
}
