#include "way.h"

int Way::getNWayIS(int nTrack, int n)
{
    return nWayIS[nTrack][n];
}

int Way::getCountPlusIS(int cis)
{
    return countPlusIS[cis];
}

int Way::getCountMinusIS(int cis)
{
    return countMinusIS[cis];
}

int Way::getXISR(int nt, int n, int np)
{
    return  xISR[nt][n][np];
}
int Way::getYISR(int nt, int n, int np)
{
    return  yISR[nt][n][np];
}

int Way::getXISL(int nt, int n, int np)
{
    return  xISL[nt][n][np];
}

int Way::getYISL(int nt, int n, int np)
{
    return  yISL[nt][n][np];
}

int Way::getCIS()
{
    return cIS;
}

int Way::getCountStripPlus()
{
    return countStripPlus;
}

int Way::getCountStripMinus()
{
    return countStripMinus;
}

void Way::setLength(int l)
{
    lengthWay=l;
}

int Way::getLengthWay()
{
    return lengthWay;
}

bool Way::posWay()
{
    if (vertikalWay)
        return Vertical;
    else
        return Horisontal;
}

bool Way::towards()
{
    if (tw)
        return true;
    else
        return false;
}


void Way::setX(int n, int _x)
{
    //X[n]=_x;
}

void Way::setY(int n, int _y)
{
    //Y[n]=_y;
}

int Way::x(int i, int j, int k)
{
    return X[i][j][k];
}

int Way::y(int i, int j, int k)
{
    return Y[i][j][k];
}

void Way::setTowards(bool tow)
{
    tw=tow;
}

void Way::setCountStripPlus(int c)
{
    countStripPlus=c;
}

void Way::setCountStripMinus(int c)
{
    countStripMinus=c;
}
