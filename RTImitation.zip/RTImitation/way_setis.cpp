#include "way.h"

const int toW=1; //Полосы по направлению
const int unToW=2; //Полосы против направления


void Way::setIS(int xc, int yc, int csP, int csM, bool pos, int nWay)
{

    /*xIS.resize(cIS+1);
    yIS.resize(cIS+1);*/

    xISR[toW].resize(cIS+1); //увеличиваем кол-во перекрестков на 1
    xISL[toW].resize(cIS+1);
    yISR[toW].resize(cIS+1);
    yISL[toW].resize(cIS+1);

    xISR[toW][cIS].resize(pos==Horisontal ? csP : csM); //увеличиваем кол-во полос для поворота направо
    yISR[toW][cIS].resize(pos==Horisontal ? csP : csM);
    xISL[toW][cIS].resize(pos==Horisontal ? csM : csP); //увеличиваем кол-во полос для поворота налево
    yISL[toW][cIS].resize(pos==Horisontal ? csM : csP);

    xISR[unToW].resize(cIS+1); //увеличиваем кол-во перекрестков на 1
    xISL[unToW].resize(cIS+1);
    yISR[unToW].resize(cIS+1);
    yISL[unToW].resize(cIS+1);

    xISR[unToW][cIS].resize(pos==Horisontal ? csM : csP); //увеличиваем кол-во полос для поворота направо
    yISR[unToW][cIS].resize(pos==Horisontal ? csM : csP);
    xISL[unToW][cIS].resize(pos==Horisontal ? csP : csM); //увеличиваем кол-во полос для поворота налево
    yISL[unToW][cIS].resize(pos==Horisontal ? csP : csM);

    nWayIS[toW].resize(cIS+1);
    nWayIS[unToW].resize(cIS+1);

    countPlusIS.resize(cIS+1);
    countMinusIS.resize(cIS+1);

    countPlusIS[cIS]=csP;
    countMinusIS[cIS]=csM;
    
    cMin.resize(cIS+1);
    cMax.resize(cIS+1);
    
//На этом моменте я сдался и окончательно признал факт наличия только вертикальных и горизонтальных дорог Т_Т (18.04)


    if (horizontalWay)
    {
        for (int i=0; i<csP; ++i)
        {
            xISR[toW][cIS][i]=(i ? xISR[toW][cIS][i-1] : xc)-dbr/ (i ? 1 : 2);
            yISR[toW][cIS][i]= yc + (dbr/2) + (dbr*(countStripPlus-1));//(i ? yISR[toW][cIS][i-1] : yc) +dbr/ (i ? 1 : 2);
            
            if (i==csP-1)
                cMin[cIS]=xISR[toW][cIS][i];
            //qDebug() << xISR[toW][cIS][i] << yISR[toW][cIS][i];
        }

        //for (int j=0; j<countStripPlus; ++j)
        for (int i=0; i<csM; ++i)
        { //xISL[toW][cIS][0] - [0] Т.к. налево только с крайней левой полосы
            xISL[toW][cIS][i]=(i ? xISL[toW][cIS][i-1] : xc)+dbr/ (i ? 1 : 2);
            yISL[toW][cIS][i]= yc + (dbr/2);//(i ? yISL[toW][cIS][i-1] : yc) +dbr/ (i ? 1 : 2);
            /*qDebug() << xISL[toW][cIS][i];
            qDebug() << toW << cIS << i;
            qDebug() << "========";*/
        }

        nWayIS[toW][cIS]=nWay;



        for (int i=0; i<csM; ++i)
        {
            xISR[unToW][cIS][i]=(i ? xISR[unToW][cIS][i-1] : xc)+dbr/ (i ? 1 : 2);
            yISR[unToW][cIS][i]= yc - (dbr/2) - (dbr*(countStripMinus-1));//(i ? yISR[unToW][cIS][i-1] : yc) -dbr/ (i ? 1 : 2);
            
            if (i==csM-1)
                cMax[cIS]=xISR[unToW][cIS][i];
            /*qDebug() << xISR[unToW][cIS][i];
            qDebug() << unToW << cIS << i;
            qDebug() << "========";*/
        }

        for (int i=0; i<csP; ++i)
        {
            xISL[unToW][cIS][i]=(i ? xISL[unToW][cIS][i-1] : xc)-dbr/ (i ? 1 : 2);
            yISL[unToW][cIS][i]=yc - (dbr/2);//(i ? yISL[unToW][cIS][i-1] : yc) -dbr/ (i ? 1 : 2);
            //qDebug() << xISL[unToW][cIS][i];
            /*qDebug() << xISL[unToW][cIS][i];
            qDebug() << unToW << cIS << i;
            qDebug() << "========";*/
        }

        nWayIS[unToW][cIS]=nWay;

    }
    else
    {
        for (int i=0; i<csM; ++i)
        {
            xISR[toW][cIS][i]= xc - (dbr/2) - (dbr*(countStripPlus-1));//(i ? xISR[toW][cIS][i-1] : xc) -dbr/ (i ? 1 : 2);
            yISR[toW][cIS][i]=(i ? yISR[toW][cIS][i-1] : yc)-dbr/ (i ? 1 : 2);

            if (i==csM-1)
                cMin[cIS]=yISR[toW][cIS][i];
        }

        for (int i=0; i<csP; ++i)
        {
            xISL[toW][cIS][i]=xc - (dbr/2);//(i ? xISL[toW][cIS][i-1] : xc) -dbr/ (i ? 1 : 2);
            yISL[toW][cIS][i]=(i ? yISL[toW][cIS][i-1] : yc)+dbr/ (i ? 1 : 2);
        }

        nWayIS[toW][cIS]=nWay;

        for (int i=0; i<csP; ++i)
        {
            xISR[unToW][cIS][i]= xc + (dbr/2) + (dbr*(countStripMinus-1));//(i ? xISR[unToW][cIS][i-1] : xc) +dbr/ (i ? 1 : 2);
            yISR[unToW][cIS][i]=(i ? yISR[unToW][cIS][i-1] : yc)+dbr/ (i ? 1 : 2);

            if (i==csP-1)
                cMax[cIS]=yISR[unToW][cIS][i];
        }

        for (int i=0; i<csM; ++i)
        {
            xISL[unToW][cIS][i]=xc + (dbr/2);//(i ? xISL[unToW][cIS][i-1] : xc) +dbr/ (i ? 1 : 2);
            yISL[unToW][cIS][i]=(i ? yISL[unToW][cIS][i-1] : yc)-dbr/ (i ? 1 : 2);
        }


        nWayIS[unToW][cIS]=nWay;

    }
    ++cIS;
//qDebug() << cIS;
}


