#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "car.h"
#include "stl.h"
#include "intersection.h"
#include "trafficlights.h"
#include "way.h"
#include "sclanes.h"
#include "count_cars.h"

#include <QMainWindow>
#include <QWidget>
#include <QTimer>
#include <QResizeEvent>
#include <QGraphicsScene>
#include <QGraphicsSceneMouseEvent>
#include <QGraphicsItem>
#include <QGraphicsItemGroup>
#include <QTimer>
#include <QDebug>
#include <QString>
#include <cmath>
#include <time.h>
#include <cstdlib>
#include <QMessageBox>
#include <vector>

const bool Vertical = 1;
const bool Horisontal = 0;

const int U=1;
const int R=2;
const int D=3;
const int L=4;

const int dbr=30; //dbr - distance between roads (расстояние между путями)
const int lTl=25; //расстояние от пересечения дороги до стоп линии перекрестка

const int intervalTLDefault=3000;

const int intervalTL=10; //интервал для таймера светофора
const int mainInterval=3;

const int lenghtCar=16;
const int deltaCar=10;

//Расстояние при котором машина будет останавливаться, если слева есть другая машина (Left Turn)
const int LT=lenghtCar+5;
//Расстояние при котором машина будет останавливаться, если справа есть другая машина (Right Turn)
const int RT=lenghtCar+ deltaCar*2;

const int lastLane=347; //признак крайней полосы

namespace Ui {
class MainWindow;
}





class Car;

class Way;

class stl;

class sclanes;

class count_cars;



class trafficLights;

class interSection;

class paintScene;

class MainWindow : public QMainWindow
{
    Q_OBJECT

    int* a; //переменная для таймера
    Car* car; //машины
    //paintScene PS;

    int* pointX; //координаты точек спавна/деспавная
    int* pointY;

    int countPoint; //количество точек спавнов/деспавна обычно количество дорог *2
    int random;

    int randWay; //переменный для стартового назначения дороги и пути
    int randTrack;
    int randLane;


    // временные переменные для хранения номеров
    int nISWay; //номер пересекаемой дороги для текущего пересечения
    int carNWay; //номер дороги, на кот. находится машина
    int carNTrack; //номер направления, на кот. находится машина 1 или 2
    int carNLane; //номер полосы, на кот. находится машина

    //Для взаимодейсвия между машинами
    bool tempSpeed;
    //stl settingTL;

    bool GO;

    //bool firstPress; //При отсутствии дорог

public:
    //Way way;
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();


private:
    Ui::MainWindow *ui;
    QMessageBox msg;
    QTimer *timer;
    QTimer *mainTimer;
    QTimer *TLtimer;
    paintScene *scene;  // Объявляем графическую сцену

    //QGraphicsItem *objCar;

    QGraphicsItemGroup *objCar;

    //обработчик перекрестков во время движения
    bool handlerIS(int nCar);
    //обработчик светофоров во время движения
    bool handlerTL(int nCar);
    //обработчик взаимодействия машин (int = interaction)
    bool handlerINT(int nCar);

private slots:
    void slotTimer();
    void on_go_clicked();

    void mainTime();
    void tlTime();
    //void on_pushStop_clicked();

    void setCarWay(int nCar);



    void resizeEvent(QResizeEvent * event);


    void on_setTL_clicked();
    void on_apply_clicked();
};

class paintScene : public QGraphicsScene
{

    Q_OBJECT
    int n=1;
    //MainWindow w;
    int x1;
    int y1;
    int x2;
    int y2;

    QMessageBox msg;
    //stl settingTL;

public:
    explicit paintScene(QObject *parent = 0);
    ~paintScene();


private:
    QPointF     previousPoint;      // Координаты предыдущей точки
    void createWay(bool direction, int x1, int y1, int x2, int y2);

private:
    // Для рисования используем события мыши
    void mousePressEvent(QGraphicsSceneMouseEvent * event);
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event);
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);

};





#endif // MAINWINDOW_H
