#include "count_cars.h"
#include "ui_count_cars.h"

extern QEventLoop loop;

count_cars::count_cars(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::count_cars)
{
    ui->setupUi(this);

    setWindowFlags(Qt::Window
         | Qt::WindowMinimizeButtonHint
         | Qt::WindowMaximizeButtonHint
         | Qt::CustomizeWindowHint);
    cc=1;
}

count_cars::~count_cars()
{
    delete ui;
}

int count_cars::getCountCars()
{
    return cc;
}

void count_cars::on_pok_clicked()
{
    cc=ui->countCars->value();
    loop.quit();
    close();
}

void count_cars::on_pcancel_clicked()
{
    loop.quit();
    close();
}
