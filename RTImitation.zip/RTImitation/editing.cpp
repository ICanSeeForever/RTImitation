#include "mainwindow.h"
#include "ui_mainwindow.h"
//#include "work.cpp"


void paintScene::createWay(bool direction, int x1, int y1, int x2, int y2)
{
    if (direction==Horisontal)
    { //если больше похоже на горизонтальную дорогу, рисуем горизонтальную
        addLine(x1,
                y1,
                x2,
                y1, //рисуем прямую, отталкиваясь от первой координаты Y
                QPen( Qt::black ,1,Qt::DotLine,Qt::RoundCap));

        for (int i=1; i<abs(x2-x1); ++i) //вбиваем координаты в массив
        {
            if (x1<x2) //если дорога идёт вправо
                WAY.setX(i, x1+i); //добавляем по пикселю (координате) вправо до конца дороги x2
            else //если влево
                WAY.setX(i, x1-i); //добавляем по пикселю (координате) влево до конца дороги x2


            WAY.setY(i, y1);
        }

    }
    else
    { //вертикальная дорога
        addLine(x1,
                y1,
                x1, //рисуем прямую, отталкиваясь от первой координаты X
                y2,
                QPen( Qt::black ,1,Qt::DotLine,Qt::RoundCap));

        for (int i=1; i<abs(y2-y1); ++i) //вбиваем координаты в массив
        {
            if (y1<y2) //если дорога идёт вверх
                WAY.setY(i, y1+i);
            else //если вниз
                WAY.setY(i, y1-i);


            WAY.setX(i, x1);
        }
    }
}
