#include "trafficlights.h"



bool trafficLights::beep(bool X, bool Y, int secInt)
{
    counter+=secInt;
    if (X)
    {
        if (counter>=intervalX) //Если пришло время менять направление
        {
            counter=0;
            return 1;
        }
        else
            return 0;
    }
    else
        if (Y)
        {
            if (counter>=intervalY)
            {
                counter=0;
                return 1;
            }
            else
                return 0;
        }

    return 0;
}
