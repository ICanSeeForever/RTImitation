#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <vector>

//Общие определения

extern interSection IS;
extern Way* WAY;
extern std::vector <trafficLights> Tl;
extern stl* settingTL;

extern int countTl;
extern int countWay;
extern int countCars;

extern int deb;

extern bool setTlClicked;// = 0;
extern bool setApplyClicked;// = 0;
/*
const bool Vertical = 1;
const bool Horisontal = 0;

const int U=1;
const int R=2;
const int D=3;
const int L=4;

const int dbr=15; //dbr - distance between roads (расстояние между путями)

//С какой вероятностью происходит поворот a=rand() % xxxTurn;
const int rightTurn=3;
const int leftTurn=3;

const int intervalTLDefault=5000;

const int intervalTL=10; //интервал для таймера светофора
const int mainInterval=4;
*/
bool MainWindow::handlerTL(int nCar)
{
    //Взаимодействие со светофорами

        for (int i=0; i<countTl; ++i)
        {
            if (!Tl[i].xAllowed())
            {
                if (car[nCar].getXCar() == Tl[i].getCoordX1(1, car[nCar].getNLane()) &&
                        car[nCar].getYCar() == Tl[i].getCoordY1(1, car[nCar].getNLane()))
                {
                    //mainTimer->setInterval(999999);
                    car[nCar].setSpeed(0);
                    return 0;
                }

                if (car[nCar].getXCar() == Tl[i].getCoordX1(2, car[nCar].getNLane()) &&
                        car[nCar].getYCar() == Tl[i].getCoordY1(2, car[nCar].getNLane()))
                {
                    //mainTimer->setInterval(999999);
                    car[nCar].setSpeed(0);
                    return 0;
                }
            }
            else
            {
                if (car[nCar].getXCar() == Tl[i].getCoordX1(1, car[nCar].getNLane()) &&
                        car[nCar].getYCar() == Tl[i].getCoordY1(1, car[nCar].getNLane()))
                {
                    //mainTimer->setInterval(999999);
                    car[nCar].setSpeed(1);
                    return 0;
                }

                if (car[nCar].getXCar() == Tl[i].getCoordX1(2, car[nCar].getNLane()) &&
                        car[nCar].getYCar() == Tl[i].getCoordY1(2, car[nCar].getNLane()))
                {
                    //mainTimer->setInterval(999999);
                    car[nCar].setSpeed(1);
                    return 0;
                }
            }

            if (!Tl[i].yAllowed())
            {
                if (car[nCar].getXCar() == Tl[i].getCoordX2(1, car[nCar].getNLane()) &&
                        car[nCar].getYCar() == Tl[i].getCoordY2(1, car[nCar].getNLane()))
                {
                    //mainTimer->setInterval(999999);
                    car[nCar].setSpeed(0);
                    return 0;
                }

                if (car[nCar].getXCar() == Tl[i].getCoordX2(2, car[nCar].getNLane()) &&
                        car[nCar].getYCar() == Tl[i].getCoordY2(2, car[nCar].getNLane()))
                {
                    //mainTimer->setInterval(999999);
                    car[nCar].setSpeed(0);
                    return 0;
                }
            }
            else
            {
                if (car[nCar].getXCar() == Tl[i].getCoordX2(1, car[nCar].getNLane()) &&
                        car[nCar].getYCar() == Tl[i].getCoordY2(1, car[nCar].getNLane()))
                {
                    //mainTimer->setInterval(999999);
                    car[nCar].setSpeed(1);
                    return 0;
                }

                if (car[nCar].getXCar() == Tl[i].getCoordX2(2, car[nCar].getNLane()) &&
                        car[nCar].getYCar() == Tl[i].getCoordY2(2, car[nCar].getNLane()))
                {
                    //mainTimer->setInterval(999999);
                    car[nCar].setSpeed(1);
                    return 0;
                }
            }
        }



}
