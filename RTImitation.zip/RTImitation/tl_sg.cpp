#include "trafficlights.h"






void trafficLights::setXAllow()
{
    xAllow=1;
    yAllow=0;
}

void trafficLights::setYAllow()
{
    xAllow=0;
    yAllow=1;
}

bool trafficLights::xAllowed()
{
    return xAllow;
}

bool trafficLights::yAllowed()
{
    return yAllow;
}


void trafficLights::setNWay1(int nw)
{
    nWay1=nw;
}

void trafficLights::setNWay2(int nw)
{
    nWay2=nw;
}

void trafficLights::setCoordX1(int nTrack, int coord)
{
    //coordX1[nTrack]=coord;
}

void trafficLights::setCoordY1(int nTrack, int coord)
{
    //coordY1[nTrack]=coord;
}

void trafficLights::setCoordX2(int nTrack, int coord)
{
    //coordX2[nTrack]=coord;
}

void trafficLights::setCoordY2(int nTrack, int coord)
{
    //coordY2[nTrack]=coord;
}

void trafficLights::setIntervalX(int in)
{
    intervalX=in;
}

void trafficLights::setIntervalY(int in)
{
    intervalY=in;
}

int trafficLights::getNWay1()
{
    return nWay1;
}

int trafficLights::getNWay2()
{
    return nWay2;
}

int trafficLights::getCoordX1(int nTrack, int nLane)
{
    /*if (nLane==lastLane)
        if (nTrack==1)
            return coordX1[nTrack][csP1-1];
        else
            return coordX1[nTrack][csM1-1];
    else*/
        return coordX1[nTrack][0]; //0 - ибо х тут всегда одинаков
}

int trafficLights::getCoordY1(int nTrack, int nLane)
{
    if (nLane==lastLane)
        if (nTrack==1)
            return coordY1[nTrack][csP1-1];
        else
            return coordY1[nTrack][csM1-1];
    else
        return coordY1[nTrack][nLane];
}

int trafficLights::getCoordX2(int nTrack, int nLane)
{
    if (nLane==lastLane)
        if (nTrack==1)
            return coordX2[nTrack][csP2-1];
        else
            return coordX2[nTrack][csM2-1];
    else
        return coordX2[nTrack][nLane];
}

int trafficLights::getCoordY2(int nTrack, int nLane)
{
    /*if (nLane==lastLane)
        if (nTrack==1)
            return coordY2[nTrack][csP2-1];
        else
            return coordY2[nTrack][csM2-1];
    else*/
        return coordY2[nTrack][0]; // 0 - ибо Y всегда одинаков
}

int trafficLights::getIntervalX()
{
    return intervalX;
}

int trafficLights::getIntervalY()
{
    return intervalY;
}

int trafficLights::getX0()
{
    return x0;
}

int trafficLights::getY0()
{
    return y0;
}
