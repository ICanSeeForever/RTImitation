#include "trafficlights.h"
extern Way* WAY;


void trafficLights::setTL(int nw1, int nw2, int xc, int yc, int cw1, int cw2)
{
    nWay1=nw1;
    nWay2=nw2;

    x0=xc;
    y0=yc;

    csP1=WAY[nWay1].getCountStripPlus();
    csM1=WAY[nWay1].getCountStripMinus();

    csP2=WAY[nWay2].getCountStripPlus();
    csM2=WAY[nWay2].getCountStripMinus();


    coordX1[1].resize(csP1);
    coordY1[1].resize(csP1);

    coordX1[2].resize(csM1);
    coordY1[2].resize(csM1);


    coordX2[1].resize(csP2);
    coordY2[1].resize(csP2);

    coordX2[2].resize(csM2);
    coordY2[2].resize(csM2);

    if (cw1==R)
    {
//qDebug() << 0;
        for (int i=0; i<csP1; ++i)
        {//qDebug() << 0.1 << csP1;
            coordX1[1][i]=xc-(dbr/ 2)-lTl -(dbr*(csP2-1));//qDebug() << 0.2;
            coordY1[1][i]=yc+(dbr/ 2) +(dbr*i);//-lTl;
            //qDebug() << 0.3;
        }
//qDebug() << 1;
        for (int i=0; i<csM1; ++i)
        {
            coordX1[2][i]=xc+(dbr/ 2)+lTl +(dbr*(csM2-1));
            coordY1[2][i]=yc-(dbr/ 2) -(dbr*i);//+lTl;
        }
//qDebug() << 2;
    }

    if (cw2==U)
    {
        for (int i=0; i<csP2; ++i)
        {
            coordX2[1][i]=xc-(dbr/ 2) -(dbr*i);
            coordY2[1][i]=yc-(dbr/ 2)-lTl -(dbr*(csM1-1));
        }
//qDebug() << 3;
        for (int i=0; i<csM2; ++i)
        {
            coordX2[2][i]=xc+(dbr/ 2) +(dbr*i);
            coordY2[2][i]=yc+(dbr/ 2)+lTl +(dbr*(csP1-1));
        }
//qDebug() << 4;
    }
qDebug() << x0 << y0;

qDebug() << coordX1[1] << coordY1[1];
qDebug() << coordX1[2] << coordY1[2];

qDebug() << coordX2[1] << coordY2[1];
qDebug() << coordX2[2] << coordY2[2];

    /*
    if (cw1==R)
    {
        coordX1[1]=xc-dbr-lTl;
        coordY1[1]=yc+dbr;//-lTl;

        coordX1[2]=xc+dbr+lTl;
        coordY1[2]=yc-dbr;//+lTl;
    }
    else
        if (cw1==L)
        {
            coordX1[1]=xc+dbr+lTl;
            coordY1[1]=yc-dbr;

            coordX1[2]=xc-dbr-lTl;
            coordY1[2]=yc+dbr;
        }

    if (cw2==U)
    {
        coordX2[1]=xc+dbr;
        coordY2[1]=yc+dbr+lTl;

        coordX2[2]=xc-dbr;
        coordY2[2]=yc-dbr-lTl;
    }
    else
        if (cw2==D)
        {
            coordX2[1]=xc-dbr;
            coordY2[1]=yc-dbr-lTl;

            coordX2[2]=xc+dbr;
            coordY2[2]=yc+dbr+lTl;
        }
*/
}
