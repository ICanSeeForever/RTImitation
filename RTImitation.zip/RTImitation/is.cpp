#include "intersection.h"





void interSection::setIS(int nWay1, int nWay2, int xc, int yc)
{


    xIS[nWay1][nWay2]=xc;
    yIS[nWay1][nWay2]=yc;

    //по сути, матрица симметрична
    xIS[nWay2][nWay1]=xc;
    yIS[nWay2][nWay1]=yc;

    /*for (int i=0; i<cWay; ++i)
    {
        for (int j=0; j<cWay; ++j)
        {
            if (xIS[i][j])
            {
                qDebug() << "Перекрёсток";
            }
            debugg=debugg + "    " + QString::number(xIS[i][j]);
        }
        qDebug() << debugg;
        debugg = "";
    }
    qDebug() << "---------";
    //++cIS;*/
}

void interSection::setCWay(int c)
{
    cWay=c;

    xIS.resize(cWay);
    yIS.resize(cWay);

    for (int i=0; i<cWay; ++i)
    {
        xIS[i].resize(cWay);
        yIS[i].resize(cWay);
    }
    //qDebug() << cWay;


}

int interSection::getXIS(int nWay1, int nWay2)
{
    return xIS[nWay1][nWay2];
}

int interSection::getYIS(int nWay1, int nWay2)
{
    return yIS[nWay1][nWay2];
}
