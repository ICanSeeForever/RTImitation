#if 1
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <vector>

extern QEventLoop loop;
//Общие определения

extern interSection IS;
extern Way* WAY;
//extern std::vector <trafficLights> Tl;
extern stl* settingTL;

//extern int countTl;
extern int countWay;
//extern int countCars;


//extern bool setTlClicked;// = 0;
extern bool setApplyClicked;// = 0;
/*
const bool Vertical = 1;
const bool Horisontal = 0;*/


void MainWindow::on_apply_clicked()
{
    setApplyClicked = 1;


    ui->setTL->setEnabled(true);
    ui->go->setEnabled(true);
    ui->apply->setEnabled(false);
    //ui->pushStop->setEnabled(true);

    //====== Создание точек спавна/деспавна на концах дорог ======
        countPoint=countWay*2; //*2 ибо по 2 точки на каждой дороге

        //создаём сами точки
        pointX = new int[countPoint];
        pointY = new int[countPoint];

        int tempPoint = 0;
        for (int i=0; i<countWay; ++i)
        {
            for (int j=0; j<2; ++j) //по 2 точки на каждую дорогу (на концах)
            {
                if (j==0)
                {
                    pointX[tempPoint]=WAY[i].x(0,0,1);//получаем первую координату центральной линии дороги i
                    pointY[tempPoint]=WAY[i].y(0,0,1);
                }
                else
                {
                    pointX[tempPoint]=WAY[i].x(0,0,WAY[i].getLengthWay());//получаем вторую координату центральной линии дороги i
                    pointY[tempPoint]=WAY[i].y(0,0,WAY[i].getLengthWay());
                }

                ++tempPoint;
            }
        }

        /*for (int i=0; i<countPoint; ++i)
        {
            qDebug() << "x:" << pointX[i] << "y:" << pointY[i];
        }*/
    //============================================================



    //==============Построение пути для машины====================
        //по сути, нужно сделать граф пересечения дорог
        //пока что, не актуально
    //============================================================



    //==============Создание точек перекретска====================
    //qDebug() << WAY[0].posWay() << WAY[1].posWay();

        //Проходим по всем дорогам и ищем перекрёстки
        for (int now=0; now<countWay; ++now)
        {
            for (int expect=0; expect<countWay; ++expect)
            {
                //если не одна и та же дорога
                if (now != expect)
                {
                    if (WAY[now].posWay() != WAY[expect].posWay()) //проверка, что это не паралелльные дороги
                    {

                        QPoint a;
                        QPoint b;
                        QPoint c;
                        QPoint d;

                        a.setX(WAY[now].x(0,0,1));
                        a.setY(WAY[now].y(0,0,1));
                        b.setX(WAY[now].x(0,0,WAY[now].getLengthWay()));
                        b.setY(WAY[now].y(0,0,WAY[now].getLengthWay()));

                        c.setX(WAY[expect].x(0,0,1));
                        c.setY(WAY[expect].y(0,0,1));
                        d.setX(WAY[expect].x(0,0,WAY[expect].getLengthWay()));
                        d.setY(WAY[expect].y(0,0,WAY[expect].getLengthWay()));

                        int xc=0;
                        int yc=0;

                        xc=-((a.x()*b.y()-b.x()*a.y())*(d.x()-c.x())-(c.x()*d.y()-d.x()*c.y())*
                             (b.x()-a.x()))/((a.y()-b.y())*(d.x()-c.x())-(c.y()-d.y())*(b.x()-a.x()));

                        yc=-((c.y()*d.x()-d.y()*c.x())*(b.y()-a.y())-(a.y()*b.x()-b.y()*a.x())*
                             (d.y()-c.y()))/((c.x()-d.x())*(b.y()-a.y())-(a.x()-b.x())*(d.y()-c.y()));


                        // Проверяем, являются ли эти 2 дороги перекрестком
                        bool C=0;
                        for (int i=1; i<WAY[now].getLengthWay(); ++i)
                        {
                            if (WAY[now].posWay()==Horisontal)
                            {
                                if (WAY[now].x(0,0,i)==WAY[expect].x(0,0,1))
                                {
                                    for (int j=1; j<WAY[expect].getLengthWay(); ++j)
                                    {
                                        if (WAY[expect].y(0,0,j)==WAY[now].y(0,0,i))
                                        {
                                            C=1;
                                            break;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                if (WAY[now].y(0,0,i)==WAY[expect].y(0,0,1))
                                {
                                    for (int j=1; j<WAY[expect].getLengthWay(); ++j)
                                    {
                                        if (WAY[expect].x(0,0,j)==WAY[now].x(0,0,i))
                                        {
                                            C=1;
                                            break;
                                        }
                                    }
                                }
                            }

                            if (C)
                                break;

                        }
                        if (C)
                        {
                            WAY[now].setIS(xc, yc, WAY[expect].getCountStripPlus(),
                                           WAY[expect].getCountStripMinus(), WAY[expect].posWay(),expect);
                            //дабы определить количество именно перекрёстков, т.е. перекресток а и в равер в и а
                            if (now<expect)
                            {
                                IS.setIS(now,expect,xc,yc);
                                /*++deb;
                                qDebug() << deb;*/
                            }
                        }


                        //qDebug() << xc << yc;



                        /*if (C)
                        scene->addRect(xc-8,yc-8,16,16,    QPen(Qt::NoPen),QBrush(Qt::black));*/

                        C=0;
                    }
                }
            }
        }


    //============================================================

    //==================Создание светофоров=======================
        /*++countTl;
        Tl.resize(countTl);
        //IS.getXIS(1,1);
        Tl[0].setTL(0,1, IS.getXIS(0,1),IS.getYIS(0,1),
                    (WAY[0].x(0,0,1) < WAY[0].x(0,0,2) ? R : L),
                    (WAY[1].x(0,0,1) < WAY[1].x(0,0,2) ? D : U) );*/

    //============================================================
}
#endif
