#include "car.h"
#include "QDebug"



Car::Car()
{
    xWay.resize(9999);
    yWay.resize(9999);
}

void Car::setXWay(int n, int x)
{
    xWay[n]=x;
}

void Car::setYWay(int n, int y)
{
    yWay[n]=y;
}

int Car::getXWay(int n)
{
    return xWay[n];
}

int Car::getYWay(int n)
{
    return yWay[n];
}

void Car::setXCar(int x)
{
    xCar = x;
}

void Car::setYCar(int y)
{
    yCar = y;
}

void Car::setSpeed(int speed)
{
    speedCar=speed;
}

void Car::setNWay(int n)
{
    nWay=n;
}

void Car::setNTrack(int n)
{
    nTrack=n;
}

void Car::setNLane(int n)
{
    nLane=n;
}

void Car::setTurnedNow(bool n)
{
    turnedNow=n;
}

void Car::setSpawned(bool n)
{
    spawned=n;
}

void Car::setTurnedFromThisIS(bool n)
{
    turnedFromThisIS=n;
}


int Car::getXCar()
{
    return xCar;
}

int Car::getYCar()
{
    return yCar;
}

int Car::getSpeed()
{
    return speedCar;
}

int Car::getNWay()
{
    return nWay;
}

int Car::getNTrack()
{
    return nTrack;
}

int Car::getNLane()
{
    return nLane;
}

bool Car::getTurnedNow()
{
    return turnedNow;
}

bool Car::getSpawned()
{
    return spawned;
}

bool Car::getTurnedFromThisIS()
{
    return turnedFromThisIS;
}
