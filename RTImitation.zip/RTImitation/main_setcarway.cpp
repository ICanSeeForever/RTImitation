#if 1
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <vector>


//Общие определения
extern Way* WAY;
extern int countWay;
extern bool spawned;





void MainWindow::setCarWay(int nCar)
{
    randWay=rand() % countWay ; //задаём рандомно дорогу спавна
    randTrack=(rand() % 2 )+1; //задаём рандомно путь спавна (+1 ибо 0 - ось)
    if (randTrack==1)
        randLane=rand() % WAY[randWay].getCountStripPlus();
    if (randTrack==2)
        randLane=rand() % WAY[randWay].getCountStripMinus();
    //временно. Устанавливаем стартовые настройки для машины

    /*randWay=1;
    randTrack=1;
    randLane=0;*/

    car[nCar].setNWay(randWay);
    car[nCar].setNTrack(randTrack);
    car[nCar].setNLane(randLane);
    //qDebug() << randWay << randTrack <<randLane;

    if (car[nCar].getNTrack()==1)
        a[nCar]=0;
    else
        a[nCar]=WAY[randWay].getLengthWay()-1;
    car[nCar].setSpawned(true);
}


#endif
