#if 1

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <vector>

QEventLoop loop;
//Общие определения

extern interSection IS;
extern Way* WAY;
extern std::vector <trafficLights> Tl;
extern stl* settingTL;
extern sclanes* settingCL;

extern int countTl;
extern int countWay;
//extern int countCars;

//extern int deb;

extern bool setTlClicked;// = 0;
extern bool setApplyClicked;// = 0;




void paintScene::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    if (!setApplyClicked)
    {

        settingCL[0].show();
        loop.exec();

        WAY[countWay].setCountStripPlus(settingCL[0].getCp());
        WAY[countWay].setCountStripMinus(settingCL[0].getCm());

        /*WAY[countWay].setCountStripPlus(1);
        WAY[countWay].setCountStripMinus(2);*/

        if (abs(x2-x1)>abs(y2-y1))
        { //если больше похоже на горизонтальную дорогу, рисуем горизонтальную

            //********** Сохранение координат дороги ************
            for (int i=1; i<abs(x2-x1); ++i) //вбиваем координаты в массив
            {

                if (x1<x2) //если дорога идёт вправо//добавляем по пикселю (координате) вправо до конца дороги x2
                {
                    //WAY[countWay].setWay(Horisontal,x1+i,y1, i, R);
                    //WAY[countWay].setTowards(true);
                }
                else //если влево
                {
                    //WAY[countWay].setWay(Horisontal,x1-i,y1, i, L); //добавляем по пикселю (координате) влево до конца дороги x2
                    x1+=x2;
                    x2=x1-x2;
                    x1=x1-x2;
                    //WAY[countWay].setTowards(false);
                }
                WAY[countWay].setTowards(true);
                WAY[countWay].setWay(Horisontal,x1+i,y1, i, R);
                //устанавливаем длину дороги
                if (i==abs(x2-x1)-1)
                {
                    //qDebug() << WAY.getLengthWay();
                    WAY[countWay].setLength(i);

                    //Добавляем признак конца дороги
                    if (x1<x2)
                    {
                        WAY[countWay].setWay(Horisontal,0,0, i+1, R);
                        WAY[countWay].setWay(Horisontal,-100,-100, i+2, R);
                    }
                    else //если влево
                    {
                        WAY[countWay].setWay(Horisontal,0,0, i+1, L);
                        WAY[countWay].setWay(Horisontal,-100,-100, i+2, L);
                    }

                }
            }

            //****************************************************




            // *********** Отрисовка ************
            clear();
            for (int i=0; i<=countWay; ++i)
            {

                //рисуем оригинальную линию
                addLine(WAY[i].x(0,0,1/*ибо 0 - верхний левый угол*/),
                        WAY[i].y(0,0,1),
                        WAY[i].x(0,0,WAY[i].getLengthWay()),
                        WAY[i].y(0,0,WAY[i].getLengthWay()), //рисуем прямую, отталкиваясь от первой координаты Y
                        QPen( Qt::black ,1,Qt::DotLine,Qt::RoundCap));

                //рисуем дороги, идущие по направлению
                for (int j=0; j<WAY[i].getCountStripPlus(); ++j)
                {
                    addLine(WAY[i].x(1,j,1/*ибо 0 - верхний левый угол*/),
                            WAY[i].y(1,j,1),
                            WAY[i].x(1,j,WAY[i].getLengthWay()),
                            WAY[i].y(1,j,WAY[i].getLengthWay()), //рисуем прямую, отталкиваясь от первой координаты Y
                            QPen( Qt::black ,1,Qt::SolidLine,Qt::RoundCap));
                }

                //рисуем дороги, идущие против направления
                for (int j=0; j<WAY[i].getCountStripMinus(); ++j)
                {
                    addLine(WAY[i].x(2,j,1),
                            WAY[i].y(2,j,1),
                            WAY[i].x(2,j,WAY[i].getLengthWay()),
                            WAY[i].y(2,j,WAY[i].getLengthWay()), //рисуем прямую, отталкиваясь от первой координаты Y
                            QPen( Qt::black ,1,Qt::SolidLine,Qt::RoundCap));
                }
            }
            // **********************************
        }





        else
        { //вертикальная дорога

            //********** Сохранение координат дороги ************
            for (int i=1; i<abs(y2-y1); ++i) //вбиваем координаты в массив
            {
                if (y1<y2) //если дорога идёт вверх
                {
                    //WAY[countWay].setWay(Vertical, x1, y1+i, i, U);
                    //WAY[countWay].setTowards(true);
                }
                else //если вниз
                {
                    //WAY[countWay].setWay(Vertical, x1, y1-i, i, D);
                    y1+=y2;
                    y2=y1-y2;
                    y1=y1-y2;
                    //WAY[countWay].setTowards(false);
                }
                WAY[countWay].setTowards(true);
                WAY[countWay].setWay(Vertical, x1, y1+i, i, U);

                if (i==abs(y2-y1)-1)
                {
                    WAY[countWay].setLength(i);
                    //qDebug() << WAY[countWay].getLengthWay();

                    //Устанавливаем признак конца дороги
                    if (y1<y2) //если дорога идёт вверх
                    {
                        WAY[countWay].setWay(Vertical, 0, 0, i+1, U);
                        WAY[countWay].setWay(Vertical, -100, -100, i+2, U);
                    }
                    else //если вниз
                    {
                        WAY[countWay].setWay(Vertical, 0, 0, i+1, D);
                        WAY[countWay].setWay(Vertical, -100, -100, i+2, D);
                    }
                }
            }
            //****************************************************



            // *********** Отрисовка ************
            clear();

            for (int i=0; i<=countWay; ++i)
            {
                //рисуем оригинальную линию
                addLine(WAY[i].x(0,0,1/*ибо 0 - верхний левый угол*/),
                        WAY[i].y(0,0,1),
                        WAY[i].x(0,0,WAY[i].getLengthWay()),
                        WAY[i].y(0,0,WAY[i].getLengthWay()),
                        QPen( Qt::black ,1,Qt::DotLine,Qt::RoundCap));

                //рисуем дороги, идущие по направлению
                for (int j=0; j<WAY[i].getCountStripPlus(); ++j)
                {
                    addLine(WAY[i].x(1,j,1/*ибо 0 - верхний левый угол*/),
                            WAY[i].y(1,j,1),
                            WAY[i].x(1,j,WAY[i].getLengthWay()),
                            WAY[i].y(1,j,WAY[i].getLengthWay()), //рисуем прямую, отталкиваясь от первой координаты Y
                            QPen( Qt::black ,1,Qt::SolidLine,Qt::RoundCap));
                }

                //рисуем дороги, идущие против направления
                for (int j=0; j<WAY[i].getCountStripMinus(); ++j)
                {
                    addLine(WAY[i].x(2,j,1),
                            WAY[i].y(2,j,1),
                            WAY[i].x(2,j,WAY[i].getLengthWay()),
                            WAY[i].y(2,j,WAY[i].getLengthWay()), //рисуем прямую, отталкиваясь от первой координаты Y
                            QPen( Qt::black ,1,Qt::SolidLine,Qt::RoundCap));
                }
            }
            // **********************************

        }


        ++countWay;
        IS.setCWay(countWay);


    }


}

#endif
