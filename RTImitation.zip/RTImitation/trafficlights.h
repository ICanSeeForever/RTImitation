#ifndef TRAFFICLIGHTS_H
#define TRAFFICLIGHTS_H

#include <vector>
#include <QString>
#include "mainwindow.h"

/*const bool Vertical = 1;
const bool Horisontal = 0;

const int U=1;
const int R=2;
const int D=3;
const int L=4;

const int dbr=15; //dbr - distance between roads (расстояние между путями)
const int lTl=20; //расстояние от пересечения дороги до стоп линии перекрестка*/

class trafficLights
{
    //рассматриваем светофор на двух пересекающихся дорогах
    int nWay1;
    int nWay2;

    int x0;
    int y0;

    int csP1;
    int csM1;

    int csP2;
    int csM2;


    //2 номера песечений (массив состоит из двух значений. По напр и против напр)
    std::vector<int> nIS1;
    std::vector<int> nIS2;
    // coord[i] - отвечает за расположение координаты светофора
    // i - номер направления
    //1 и 2 - для обеих дорог
    std::vector< std::vector<int>> coordX1;
    std::vector< std::vector<int>> coordY1;
    std::vector< std::vector<int>> coordX2;
    std::vector< std::vector<int>> coordY2;

    //==== настройки светофора
    int intervalX;
    int intervalY;
    bool xAllow;
    bool yAllow;
    int counter;


public:
    trafficLights();
    void setNWay1(int nw);
    void setNWay2(int nw);
    void setCoordX1(int nTrack, int coord);
    void setCoordY1(int nTrack, int coord);
    void setCoordX2(int nTrack, int coord);
    void setCoordY2(int nTrack, int coord);
    void setIntervalX(int in);
    void setIntervalY(int in);
    void setXAllow();
    void setYAllow();

    bool xAllowed();
    bool yAllowed();

    //Счетчик, по которому переключается светофор (X, Y - по какой дороге сейчас идёт отсчет, secInt - интервал таймера)
    bool beep(bool X, bool Y, int secInt);

    int getNWay1();
    int getNWay2();
    int getCoordX1(int nTrack, int nLane);
    int getCoordY1(int nTrack, int nLane);
    int getCoordX2(int nTrack, int nLane);
    int getCoordY2(int nTrack, int nLane);
    int getIntervalX();
    int getIntervalY();
    int getX0();
    int getY0();

    //nw - номера дорог
    //xc/yc - коры пересечения осей
    //cw - направление дороги (и зачем я его ввёл...)
    void setTL(int nw1, int nw2, int xc, int yc, int cw1, int cw2);
};

#endif // TRAFFICLIGHTS_H
