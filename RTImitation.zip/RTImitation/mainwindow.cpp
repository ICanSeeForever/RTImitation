#include "mainwindow.h"
#include "ui_mainwindow.h"

extern Way* WAY;
extern sclanes* settingCL;
extern stl* settingTL;
extern count_cars* cCars;
extern int countCars;
extern bool GO;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    this->setGeometry(0,25,2048,700);

    srand( (unsigned)time( NULL ) );
    scene = new paintScene();       // Инициализация графической сцены
    ui->graphicsView->setScene(scene);  // Устанавка графической сцены

    timer = new QTimer();       // Инициализация таймера
    connect(timer, &QTimer::timeout, this, &MainWindow::slotTimer);

    //testCar = new QGraphicsItem;

    timer->start(100);          // Запуск таймера

    //ui->graphicsView->setAlignment(Qt::AlignAbsolute);

    WAY = new Way[32];

    //в иных вариантах (без указателя, и с "->" вылетают ошибки рантайма
    settingTL = new stl[1];
    settingCL = new sclanes[1];
    cCars = new count_cars[1];

    /*int width = ui->graphicsView->width();      // определяем ширину нашего виджета
    int height = ui->graphicsView->height();    // определяем высоту нашего виджета*/

    GO=false;
}

void MainWindow::resizeEvent(QResizeEvent *event)
{
    if (GO)
        for (int i=0; i<countCars; ++i)
            objCar[0].setTransformOriginPoint(0,0);
}


void MainWindow::slotTimer()
{
    timer->stop();
    scene->setSceneRect(0,0, ui->graphicsView->width() - 20, ui->graphicsView->height() - 20);

}

MainWindow::~MainWindow()
{
    settingCL[0].close();
    settingTL[0].close();
    cCars[0].close();
    delete []settingTL;
    delete []settingCL;
    delete []cCars;
    delete ui;
}

paintScene::paintScene(QObject *parent) : QGraphicsScene(parent){}

paintScene::~paintScene(){}

/*void MainWindow::on_pushStop_clicked()
{
    //scene->clear();
    mainTimer->stop();
    TLtimer->stop();
}*/



