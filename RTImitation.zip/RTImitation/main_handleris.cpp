#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <vector>

//Общие определения

extern interSection IS;
extern Way* WAY;
extern std::vector <trafficLights> Tl;
extern stl* settingTL;

extern int countTl;
extern int countWay;
extern int countCars;

extern int deb;

extern bool setTlClicked;// = 0;
extern bool setApplyClicked;// = 0;

extern bool turned;

//С какой вероятностью происходит поворот a=rand() % xxxTurn;
extern int rightTurn;
extern int leftTurn;

/*
const bool Vertical = 1;
const bool Horisontal = 0;

const int U=1;
const int R=2;
const int D=3;
const int L=4;

const int dbr=15; //dbr - distance between roads (расстояние между путями)

//С какой вероятностью происходит поворот a=rand() % xxxTurn;
const int rightTurn=3;
const int leftTurn=3;

const int intervalTLDefault=5000;

const int intervalTL=10; //интервал для таймера светофора
const int mainInterval=4;
*/

bool MainWindow::handlerIS(int nCar)
{

    carNWay=car[nCar].getNWay();
    carNTrack=car[nCar].getNTrack();
    carNLane=car[nCar].getNLane();
    //Если горизонтальная дорога
    if (WAY[carNWay].posWay()==Horisontal)
    {
        //проходим по всем перекресткам текущей дороги
        for (int j=0; j<WAY[carNWay].getCIS(); ++j)
        {
            //Т.к. поворот напр разрешен только с крайней правой полосы
            if (carNTrack==1 && carNLane==WAY[carNWay].getCountStripPlus()-1 or
                    carNTrack==2 && carNLane==WAY[carNWay].getCountStripMinus()-1)
            {
                int m=0;
                //Устанавливаем возможность поворота только на крайнюю правую полосу
                if (carNTrack==1)
                    m=WAY[carNWay].getCountPlusIS(j) -1;
                else
                    m=WAY[carNWay].getCountMinusIS(j) -1;
                //qDebug() << m;
                //qDebug() << car[nCar].getXCar() << WAY[carNWay].getXISR(carNTrack,j,m);
                //сравниваем, есть ли пересечение Путей для поворота НАПРАВО
                if (car[nCar].getXCar()==WAY[carNWay].getXISR(carNTrack,j,m))
                {
                    random = rand() % rightTurn;
                    //qDebug() << random;
                    //рандомный шанс поворота направо
                    if (random == 0)
                    {
                        /*qDebug() << carNTrack << j << carNLane;
                        qDebug() << WAY[carNWay].getXISR(carNTrack,j,carNLane);*/
                        //Номер пересекаемой дороги
                        nISWay=WAY[carNWay].getNWayIS(carNTrack,j);
                        //qDebug() << nISWay;
                        //ищем кору пересечения на второй дороге
                        for (int i=1; i<WAY[nISWay].getLengthWay(); ++i)
                        {//k=m т.к. поворот только на крайнюю правую полосу
                            for (int k=m;k<=m;++k)
                            {//qDebug() << WAY[nISWay].x(1,k,i) << WAY[carNWay].getXISR(carNTrack,j,m);
                                //для пути по направлению
                                if (WAY[nISWay].x(1,k,i)==WAY[carNWay].getXISR(carNTrack,j,m) &&
                                        WAY[nISWay].y(1,k,i)==WAY[carNWay].getYISR(carNTrack,j,m) )
                                { //qDebug() << car[nCar].getNWay();
                                    a[nCar]=i;
                                    car[nCar].setNWay(nISWay);
                                    car[nCar].setNTrack(1);
                                    car[nCar].setNLane(m);
                                    //qDebug() << car[nCar].getNWay();
                                    car[nCar].setTurnedNow(true);
                                    car[nCar].setTurnedFromThisIS(true);
                                    return 0;
                                }
                                //для пути против направления
                                if (WAY[nISWay].x(2,k,i)==WAY[carNWay].getXISR(carNTrack,j,m) &&
                                        WAY[nISWay].y(2,k,i)==WAY[carNWay].getYISR(carNTrack,j,m))
                                {
                                    a[nCar]=i;
                                    car[nCar].setNWay(nISWay);
                                    car[nCar].setNTrack(2);
                                    car[nCar].setNLane(m);
                                    car[nCar].setTurnedNow(true);
                                    car[nCar].setTurnedFromThisIS(true);
                                    return 0;
                                }
                            }
                        }
                    }
                }
            }
            if (carNLane==0) //Т.к. поворот налево доступен только с крайней левой полосы
            {//qDebug() << WAY[carNWay].getCountMinusIS(j);
                //Перебираем все возможные повороты для поворота НАЛЕВО
                for (int m=0;
                     m<(carNTrack == 1 ? WAY[carNWay].getCountMinusIS(j) : WAY[carNWay].getCountPlusIS(j));
                     ++m)
                {
                    //сравниваем, есть ли пересечение Путей для поворота НАЛЕВО
                    if (car[nCar].getXCar()==WAY[carNWay].getXISL(carNTrack,j,m))
                    {
                        random=rand() % leftTurn;
                        //рандомный шанс поворота налево
                        if (random == 0)
                        {
                            nISWay=WAY[carNWay].getNWayIS(carNTrack,j);
                            //qDebug() << nISWay;
                            //ищем кору пересечения на второй дороге
                            for (int i=1; i<WAY[nISWay].getLengthWay(); ++i)
                            {
                                for (int k=0;k<=m;++k)
                                {
                                    //для пути по направлению
                                    if (WAY[nISWay].x(1,k,i)==WAY[carNWay].getXISL(carNTrack,j,m) &&
                                            WAY[nISWay].y(1,k,i)==WAY[carNWay].getYISL(carNTrack,j,m) )
                                    {
                                        a[nCar]=i;
                                        car[nCar].setNWay(nISWay);
                                        car[nCar].setNTrack(1);
                                        car[nCar].setNLane(m);
                                        car[nCar].setTurnedNow(true);
                                        car[nCar].setTurnedFromThisIS(true);
                                        return 0;
                                    }
                                    //для пути против направления
                                    if (WAY[nISWay].x(2,k,i)==WAY[carNWay].getXISL(carNTrack,j,m) &&
                                            WAY[nISWay].y(2,k,i)==WAY[carNWay].getYISL(carNTrack,j,m))
                                    {
                                        a[nCar]=i;
                                        car[nCar].setNWay(nISWay);
                                        car[nCar].setNTrack(2);
                                        car[nCar].setNLane(m);
                                        car[nCar].setTurnedNow(true);
                                        car[nCar].setTurnedFromThisIS(true);
                                        return 0;
                                    }
                                }
                            }

                        }
                    }
                }
            }
        }

    }
    // Если вертикальная дорога
    else
    {
        //проходим по всем перекресткам текущей дороги
        for (int j=0; j<WAY[carNWay].getCIS(); ++j)
        {
            //Т.к. поворот напр разрешен только с крайней правой полосы
            if ((carNTrack==1 && carNLane==WAY[carNWay].getCountStripPlus()-1) or
                    (carNTrack==2 && carNLane==WAY[carNWay].getCountStripMinus()-1))
                //Перебираем все возможные повороты для поворота НАПРАВО
                /*for (int m=/*0* / WAY[carNWay].getCountMinusIS(j) -1;
                     m<WAY[carNWay].getCountMinusIS(j); ++m)*/
            {
                int m=0;
                if (carNTrack==1)
                    m=WAY[carNWay].getCountMinusIS(j) -1;
                else
                    m=WAY[carNWay].getCountPlusIS(j) -1;
                //qDebug() << car[nCar].getYCar() << WAY[carNWay].getYISR(carNTrack,j,m);
                //сравниваем, есть ли пересечение Путей для поворота НАПРАВО
                if (car[nCar].getYCar()==WAY[carNWay].getYISR(carNTrack,j,m))
                {
                    random = rand() % rightTurn;
                    //qDebug() << random;
                    //рандомный шанс поворота направо
                    if (random == 0)
                    {
                        nISWay=WAY[carNWay].getNWayIS(carNTrack,j);
                        //qDebug() << "X:" << WAY[0].getXISR(1,0);
                        //qDebug() << "Y:" << WAY[0].getYISR(1,0);
                        //ищем кору пересечения на второй дороге
                        for (int i=1; i<WAY[nISWay].getLengthWay(); ++i)
                        {
                            for (int k=m;k<=m;++k)
                            {
                                if (WAY[nISWay].x(1,k,i)==WAY[carNWay].getXISR(carNTrack,j,m) &&
                                        WAY[nISWay].y(1,k,i)==WAY[carNWay].getYISR(carNTrack,j,m) )
                                {//qDebug() << "DDD";
                                    a[nCar]=i;
                                    car[nCar].setNWay(nISWay);
                                    car[nCar].setNTrack(1);
                                    car[nCar].setNLane(m);
                                    car[nCar].setTurnedNow(true);
                                    car[nCar].setTurnedFromThisIS(true);
                                    return 0;
                                }
                                if (WAY[nISWay].x(2,k,i)==WAY[carNWay].getXISR(carNTrack,j,m) &&
                                        WAY[nISWay].y(2,k,i)==WAY[carNWay].getYISR(carNTrack,j,m))
                                {//qDebug() << "SSS";
                                    a[nCar]=i;
                                    car[nCar].setNWay(nISWay);
                                    car[nCar].setNTrack(2);
                                    car[nCar].setNLane(m);
                                    car[nCar].setTurnedNow(true);
                                    car[nCar].setTurnedFromThisIS(true);
                                    return 0;
                                }
                            }
                        }
                    }
                }
            }
            if (carNLane==0)
            {
                //Перебираем все возможные повороты для поворота НАЛЕВО
                for (int m=0;
                     m<(carNTrack == 1 ? WAY[carNWay].getCountPlusIS(j) : WAY[carNWay].getCountMinusIS(j));
                     ++m)
                {
                    //сравниваем, есть ли пересечение Путей для поворота НАЛЕВО
                    if (car[nCar].getYCar()==WAY[carNWay].getYISL(carNTrack,j,m))
                    {
                        //qDebug() << "X:" << WAY[0].getXISR(1,0);
                        //qDebug() << "Y:" << WAY[0].getYISR(1,0);
                        //ищем кору пересечения на второй дороге
                        random=rand() % leftTurn;
                        //рандомный шанс поворота налево
                        if (random == 0)
                        {
                            nISWay=WAY[carNWay].getNWayIS(carNTrack,j);
                            for (int i=1; i<WAY[nISWay].getLengthWay(); ++i)
                            {
                                for (int k=0;k<=m;++k)
                                {
                                    if (WAY[nISWay].x(1,k,i)==WAY[carNWay].getXISL(carNTrack,j,m) &&
                                            WAY[nISWay].y(1,k,i)==WAY[carNWay].getYISL(carNTrack,j,m) )
                                    {
                                        a[nCar]=i;
                                        car[nCar].setNWay(nISWay);
                                        car[nCar].setNTrack(1);
                                        car[nCar].setNLane(m);
                                        car[nCar].setTurnedNow(true);
                                        car[nCar].setTurnedFromThisIS(true);
                                        return 0;
                                    }
                                    if (WAY[nISWay].x(2,k,i)==WAY[carNWay].getXISL(carNTrack,j,m) &&
                                            WAY[nISWay].y(2,k,i)==WAY[carNWay].getYISL(carNTrack,j,m))
                                    {
                                        a[nCar]=i;
                                        car[nCar].setNWay(nISWay);
                                        car[nCar].setNTrack(2);
                                        car[nCar].setNLane(m);
                                        car[nCar].setTurnedNow(true);
                                        car[nCar].setTurnedFromThisIS(true);
                                        return 0;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

}
