#include "trafficlights.h"




trafficLights::trafficLights()
{
    intervalX=5000; // 1000 = 1 сек
    intervalY=5000;

    xAllow=0;
    yAllow=0;

    counter=0;

    nIS1.resize(3);
    nIS2.resize(3);

    coordX1.resize(3);
    coordY1.resize(3);
    coordX2.resize(3);
    coordY2.resize(3);
}
