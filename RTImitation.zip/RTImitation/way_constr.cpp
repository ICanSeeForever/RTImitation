#include "way.h"



Way::Way()
{
    vertikalWay=0;
    horizontalWay=0;

    cIS=0;

    countStripPlus=5;
    countStripMinus=5;
    sumStrip=countStripPlus+countStripMinus; //2 полосы

    xISR.resize(3); //увеличиваем кол-во направлений (первый - ось, хз зачем, но пусть будет)
    xISL.resize(3);
    yISR.resize(3);
    yISL.resize(3);

    nWayIS.resize(3); //увеличиваем кол-во направлений (первый - ось, хз зачем, но пусть будет)

    X.resize(3); //3 основных направления. 0 - основная линия, 1 - проезж. части по напр, 2 - против напр.
    Y.resize(3);

    //устанавливаем количество полос для каждого направления (опять же, 0 - всегда будет 1 полоса, ибо это осн. линия)

    X[0].resize(1);
    Y[0].resize(1);

    X[1].resize(countStripPlus);
    Y[1].resize(countStripPlus);

    X[2].resize(countStripMinus);
    Y[2].resize(countStripMinus);


    /*for (int i=0; i<3; ++i)
    {
        //изначально везде по одной полосе
        X[i].resize(1);
        Y[i].resize(1);
    }*/



    //Y.resize(sumStrip);

    X[0][0].resize(9999); //расширяем вектор координат
    Y[0][0].resize(9999);

    for (int j=0; j<countStripPlus; ++j) //для каждого направления
    {
        X[1][j].resize(9999); //расширяем вектор координат
        Y[1][j].resize(9999);
    }

    for (int j=0; j<countStripMinus; ++j) //для каждого направления
    {
        X[2][j].resize(9999); //расширяем вектор координат
        Y[2][j].resize(9999);
    }

    /*
    for (int j=0; j<3; ++i) //для каждого направления
    {
        for (int j=0; j<1; ++j) //для каждого пути
        {
            X[i][j].resize(9999); //расширяем вектор координат
            Y[i][j].resize(9999);
        }
    }
*/
    /*

    X = new int[9999];
    Y = new int[9999];
    for (int i=0; i<9999; ++i)
    {
        X[i]=0;
        Y[i]=0;
    }*/
}
