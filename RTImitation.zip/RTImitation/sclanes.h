#ifndef SCLANES_H
#define SCLANES_H

#include <QWidget>
#include <QKeyEvent>

namespace Ui {
class sclanes;
}

class sclanes : public QWidget
{
    Q_OBJECT

    int cp;
    int cm;

public:
    int getCp();
    int getCm();

    void show();

    explicit sclanes(QWidget *parent = 0);
    ~sclanes();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void keyPressEvent(QKeyEvent* event);



private:
    Ui::sclanes *ui;
};

#endif // SCLANES_H
